<?php
return array(
  //
  // GENERAL
  //
  'A colorful theme to refresh the interface using different color schemes.' => 'Un thème coloré pour rafraîchir l\'interface en utilisant différents schémas de couleurs.',
);
